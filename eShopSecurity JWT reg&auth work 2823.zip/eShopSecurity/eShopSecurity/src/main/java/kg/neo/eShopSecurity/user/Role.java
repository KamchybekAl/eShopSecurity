package kg.neo.eShopSecurity.user;

public enum Role {
    USER,
    ADMIN
}
