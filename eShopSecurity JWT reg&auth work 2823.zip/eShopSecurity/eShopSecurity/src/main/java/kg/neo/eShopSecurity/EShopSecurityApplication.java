package kg.neo.eShopSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EShopSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(EShopSecurityApplication.class, args);
	}

}
